from document_parser import Document


class DocumentMerger:

    PAGE_MARKER = "\n<<<PAGE:{page}>>>\n"

    def merge(
        self,
        documents: list[Document]
    ) -> Document:

        if not documents:
            raise ValueError("没有可以合并的 Document")

        contents = []

        pages = []

        for document in documents:

            page = document.metadata.get("page")

            contents.append(
                document.content
            )

            pages.append(page)

        full_text = ""

        for document in documents:

            page = document.metadata.get("page")

            full_text += document.content

            full_text += self.PAGE_MARKER.format(
                page=page
            )

        metadata = documents[0].metadata.copy()

        metadata.pop("page", None)

        metadata["start_page"] = min(pages)
        metadata["end_page"] = max(pages)

        return Document(
            content=full_text,
            document_id=documents[0].document_id,
            metadata=metadata
        )