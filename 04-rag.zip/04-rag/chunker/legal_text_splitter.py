import re

from document_parser import Document


class LegalTextSplitter:
    ARTICLE_PATTERN = re.compile(r"第[一二三四五六七八九十百千万零〇两]+条")

    PAGE_PATTERN = re.compile(r"<<<PAGE:(\d+)>>>")

    def split_document(self, document: Document) -> list[Document]:

        text = document.content

        matches = list(self.ARTICLE_PATTERN.finditer(text))

        if not matches:
            return [document]

        chunks = []

        for i, match in enumerate(matches):

            start = match.start()

            if i + 1 < len(matches):
                end = matches[i + 1].start()
            else:
                end = len(text)

            raw_content = text[start:end]

            article = match.group()

            pages = self.PAGE_PATTERN.findall(raw_content)

            clean_content = self.PAGE_PATTERN.sub("", raw_content).strip()

            if not clean_content:
                continue

            metadata = document.metadata.copy()

            metadata["article"] = article

            if pages:
                pages = [int(page) for page in pages]

                metadata["start_page"] = min(pages)
                metadata["end_page"] = max(pages)

            metadata["chunk_index"] = i

            chunks.append(Document(content=clean_content, document_id=document.document_id, metadata=metadata))

        return chunks
