import uuid
from document_parser import DocumentParser
from text_splitter import TextSplitter
from document_cleaner import DocumentCleaner
from ..entity.models import Document
from ..retrieval.embedder import Embedder
from ..retrieval.chroma_store import ChromaStore

if __name__ == "__main__":

    parser = DocumentParser()
    cleaner = DocumentCleaner()

    documents = parser.parse("../data/立法法.pdf")

    print("原始 Document 数量：")
    print(len(documents))

    for document in documents:
        document.content = cleaner.clean(document.content)

    splitter = TextSplitter(chunk_size=500, chunk_overlap=50)

    chunks = splitter.split_documents(documents)

    print("Chunk 数量：")
    print(len(chunks))
    chromaStore = ChromaStore()
    embedder = Embedder()
    vectors: list[list[float]] = []
    docs: list[Document] = []
    for i, chunk in enumerate(chunks[:5]):
        print("=" * 60)

        print("Chunk:", i)

        print("Metadata:")
        print(chunk.metadata)

        print("Content:")
        print(chunk.content)
        vectors.append(embedder.embed(chunk.content))
        docs.append(Document(id =int(uuid.uuid4()), title='中华人民共和国立法法', page_content=chunk.content, metadata=chunk.metadata))

    chromaStore.upsert_documents(docs=docs, vectors=vectors)

    print(chromaStore.query(query_vector=embedder.embed(texts='民族自治')))
